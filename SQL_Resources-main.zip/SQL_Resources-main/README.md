# SQL Resources to Learn n Practice

## Watch SQL Interview Questions playlist: https://www.youtube.com/playlist?list=PLdOKnrf8EcP1y_LPEv7uBpzoRmlATjCVr
